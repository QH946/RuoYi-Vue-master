-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('首页轮播广告', '3', '1', 'adv', 'coupon/adv/index', 1, 0, 'C', '0', '0', 'coupon:adv:list', '#', 'admin', sysdate(), '', null, '首页轮播广告菜单');

-- 按钮父菜单ID
SELECT @parentId := LAST_INSERT_ID();

-- 按钮 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('首页轮播广告查询', @parentId, '1',  '#', '', 1, 0, 'F', '0', '0', 'coupon:adv:query',        '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('首页轮播广告新增', @parentId, '2',  '#', '', 1, 0, 'F', '0', '0', 'coupon:adv:add',          '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('首页轮播广告修改', @parentId, '3',  '#', '', 1, 0, 'F', '0', '0', 'coupon:adv:edit',         '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('首页轮播广告删除', @parentId, '4',  '#', '', 1, 0, 'F', '0', '0', 'coupon:adv:remove',       '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('首页轮播广告导出', @parentId, '5',  '#', '', 1, 0, 'F', '0', '0', 'coupon:adv:export',       '#', 'admin', sysdate(), '', null, '');