-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('首页专题【jd首页下面很多专题，每个专题链接新的页面，展示专题商品信息】', '3', '1', 'subject', 'coupon/subject/index', 1, 0, 'C', '0', '0', 'coupon:subject:list', '#', 'admin', sysdate(), '', null, '首页专题【jd首页下面很多专题，每个专题链接新的页面，展示专题商品信息】菜单');

-- 按钮父菜单ID
SELECT @parentId := LAST_INSERT_ID();

-- 按钮 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('首页专题【jd首页下面很多专题，每个专题链接新的页面，展示专题商品信息】查询', @parentId, '1',  '#', '', 1, 0, 'F', '0', '0', 'coupon:subject:query',        '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('首页专题【jd首页下面很多专题，每个专题链接新的页面，展示专题商品信息】新增', @parentId, '2',  '#', '', 1, 0, 'F', '0', '0', 'coupon:subject:add',          '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('首页专题【jd首页下面很多专题，每个专题链接新的页面，展示专题商品信息】修改', @parentId, '3',  '#', '', 1, 0, 'F', '0', '0', 'coupon:subject:edit',         '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('首页专题【jd首页下面很多专题，每个专题链接新的页面，展示专题商品信息】删除', @parentId, '4',  '#', '', 1, 0, 'F', '0', '0', 'coupon:subject:remove',       '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('首页专题【jd首页下面很多专题，每个专题链接新的页面，展示专题商品信息】导出', @parentId, '5',  '#', '', 1, 0, 'F', '0', '0', 'coupon:subject:export',       '#', 'admin', sysdate(), '', null, '');